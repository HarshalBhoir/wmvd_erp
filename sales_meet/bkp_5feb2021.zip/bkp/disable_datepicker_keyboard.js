odoo.define('sales_meet.disable_datepicker_keyboard', function (require) {
	"use strict";

	var core = require('web.core');
	var formats = require('web.formats');
	var common = require('web.form_common');
	var instance = odoo;
	var Model = require('web.Model');
	var QWeb = core.qweb;
	var _t = core._t;



	instance.web.FormView.include({
		init: function(parent, dataset, view_id, options) {
			var self = this;
			this._super(parent, dataset, view_id, options);
			console.log('Button Clicked11111111111111111111111111111111111')
		},
		
		start: function() {
			console.log('Button Clicked222222222222222222222222222222222')
			var self = this;
			this._super.apply(this, arguments);

			var date = document.getElementsByName('date');


			// this.$el.delegate('.datepicker', 'click', self.disable_keyboard);
			// var date2 = document.getElementById("expensedate").readOnly = true;

			console.log('Button Clickedaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa222222222' + date + date2)
		},
		
	 

	 //	events: {
	 //	"click .datepicker": "disable_keyboard",
		// },

		disable_keyboard: function() {
				console.log('Button Clicked333333333333333333333333333333')
				// jQuery( ".datepicker" ).datepicker({ }).attr('readonly','readonly')

				$('.datepicker').datepicker({
				   beforeShow: function(){$('input').blur();}
				});
			},


		
	});


	// var ajax = require('web.ajax');
	// var ControlPanelMixin = require('web.ControlPanelMixin');
	// var core = require('web.core');
	// var Dialog = require('web.Dialog');
	// var Model = require('web.Model');
	// var session = require('web.session');
	// var utils = require('web.utils');
	// var web_client = require('web.web_client');
	// var Widget = require('web.Widget');
	// var _t = core._t;
	// var QWeb = core.qweb;


	// var formats = require('web.formats');
	// var KanbanView = require('web_kanban.KanbanView');
	// var KanbanRecord = require('web_kanban.Record');
	// var ActionManager = require('web.ActionManager');

	// var _lt = core._lt;

	// var DisableDatepickerKeyboard = Widget.extend(ControlPanelMixin, {
	//     template: "sales_meet.DisableDatepickerKeyboardMain",
	//     events: {
	// 	    "click .datepicker": "disable_keyboard",
	// 	},

	//     init: function(parent, context) {
	//         this._super(parent, context);
	//         var self = this;
	//         this.login_user = true;
	//         this._super(parent,context);

	//     },

	//     start: function() {
	//         var self = this;

	//         var model  = new Model('calendar.event').call('get_user_meeting_details').then(function(result){
	//             this.login_user =  result[0];
	//             // self.login_user =  result[0]

	//             $('.o_meetings_dashboard').html(QWeb.render('MeetingsManagerDashboard', {widget: this}));

	//         });

	//     },


	//     disable_keyboard: function() {
	// 			console.log('Button Clicked333333333333333333333333333333')
	// 			// jQuery( ".datepicker" ).datepicker({ }).attr('readonly','readonly')

	// 			$('.selector').datepicker({
	// 			   beforeShow: function(){$('input').blur();}
	// 			});
	// 		},

	    

	// });

	// core.action_registry.add('meetings_dashboard', DisableDatepickerKeyboard);

	// return DisableDatepickerKeyboard;



});
