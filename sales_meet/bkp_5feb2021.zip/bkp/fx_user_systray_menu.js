odoo.define("sales_meet.SystrayMenu", function(require) {
    "use strict";
    var e = require("web.Widget"),
        t = require("web.SystrayMenu"),
        i = require("web.UserMenu");
    t.include({
        willStart: function() {
            var n = this,
                r = [];
            return t.Items = _.sortBy(t.Items, function(e) {
                return _.isUndefined(e.prototype.sequence) ? 50 : e.prototype.sequence
            }), t.Items.forEach(function(e) {
                var t;
                e != i && (t = new e(n), n.widgets.push(t), r.push(t.appendTo($("<div>"))))
            }), e.prototype.willStart.apply(this, arguments).then(function() {
                return Promise.all(r)
            })
        }
    })
});
